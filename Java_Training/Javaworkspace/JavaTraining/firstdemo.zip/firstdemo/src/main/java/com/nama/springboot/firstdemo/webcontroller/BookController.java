package com.nama.springboot.firstdemo.webcontroller;

import org.springframework.web.bind.annotation.RestController;
import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.nama.springboot.firstdemo.dao.BookDao;
import com.nama.springboot.firstdemo.exception.BookNotFoundException;
import com.nama.springboot.firstdemo.model.Book;
@RestController
public class BookController {

	@Autowired
	BookDao bookdao;
	@GetMapping("mybook/{bookid}")
	public String getBook1(@PathVariable int bookid,ModelMap m)
	{
	    Book b =  this.bookdao.getBook(bookid);	
	    System.out.println("Inside getbook");
	 if(b!=null)
	 {    m.addAttribute("book", b);
	 
	 }else
	 {
		 m.addAttribute("msg","book with bookid:" + bookid + "not found!");
	 }
		return "book";
	}
}
