import { HttpClient, HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, throwError } from 'rxjs';
import { Book } from './model/book';
@Injectable({
  providedIn: 'root'
})
export class BookdaoService {
 
  bookrArr:Book[] = [];
  flag:boolean=false;

  private apiServer = "http://localhost:8082";
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }
  
 constructor(private httpClient: HttpClient){ }

 addBook(book:Book): Observable<Book> {
  return this.httpClient.post<Book>(this.apiServer + '/addbook', JSON.stringify(book), 
  this.httpOptions)
  .pipe(
    catchError(this.errorHandler)
  )
}








errorHandler(error:HttpErrorResponse) {
  let errorMessage = '';
  if(error.error instanceof ErrorEvent) {
    // Get client-side error
    errorMessage = error.error.message;
  } else {
    // Get server-side error
    errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
  }
  console.log(errorMessage);
  return throwError(() => error);
}
}

/* 1st TRY


 addBook(book:Book): Observable<Book> {
  return this.httpClient.post<Book>(this.apiServer + '/addbook', JSON.stringify(book), 
  this.httpOptions)
  .pipe(
    catchError(this.errorHandler)
  )
}  

// addBook(b:Book):void
// {
//   this.httpClient.post(this.apiServer,JSON.stringify(b),this.httpOptions).subscribe(
//     (response) => {
//       console.log('book created' + response);
//     },
//     (error)=>{
//       console.log('error while posting')
//     },
//     ()=>{
//       console.log('post method complete')
//     }
//   )
//   this.bookrArr.push(b);
// }
 
getById(id:number): Observable<Book> {
  return this.httpClient.get<Book>(this.apiServer + '/book/' + id)
  .pipe(
    catchError(this.errorHandler)
  )
}

// getAll(): Book[] {
//  this.httpClient.get<Book[]>(this.apiServer + '/allbooks').subscribe(
//     (data)=> {
//       console.log('list of books' + data);
//     }
//   );
//   return this.bookrArr;
//  }


getAllBooks(): Observable<Book[]> {
  return this.httpClient.get<Book[]>(this.apiServer + '/allbooks',this.httpOptions)
  .pipe(
    catchError(this.errorHandler)
  )
}

update(id:number, book:Book): Observable<Book> {
  return this.httpClient.put<Book>(this.apiServer + '/updatebook/' + id, JSON.stringify(book), 
  this.httpOptions)
  .pipe(
    catchError(this.errorHandler)
  )
}

delete(id:number){
  return this.httpClient.delete<Book>(this.apiServer + '/rembook1/' + id, this.httpOptions)
  .pipe(
    catchError(this.errorHandler)
  )
}
errorHandler(error:HttpErrorResponse) {
  let errorMessage = '';
  if(error.error instanceof ErrorEvent) {
    // Get client-side error
    errorMessage = error.error.message;
  } else {
    // Get server-side error
    errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
  }
  console.log(errorMessage);
  return throwError(() => error);
}


}
 /*
  baseurl:string;
  httpOptions = {
    headers:new HttpHeaders({
                             'Content-Type':'application/json'
                         })
   }
  constructor(private httpClient: HttpClient) {
    console.log('bookdao service constructor called...');
     this.baseurl = 'http://localhost:5000/books';
  //  this.httpClient = httpClient;
   }
   addBook(b:Book)
   {
     console.log('inside addBook method...');
     this.httpClient.post<Book>(this.baseurl,JSON.stringify(b),this.httpOptions).subscribe(
      (response)=>{
        console.log('this is book response:'+response);
      }).pipe(
      catchError(this.errorHandler)
      )
 
   }
   getAllBooks()
   {
      return this.httpClient.get<Book[]>(this.baseurl,this.httpOptions).pipe(
        catchError(this.errorHandler)
      )
   }



   deleteBook(bookid:number)
   {
    return this.httpClient.delete<Book>(this.baseurl+'/',this.httpOptions).
    pipe(
      catchError(this.errorHandler));
   }
   


   errorHandler(httperror:HttpErrorResponse) {
    let errorMessage = '';
    if(httperror.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = httperror.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${httperror.status}\nMessage: ${httperror.message}`;
    }
    console.log(errorMessage);
    return throwError(() => httperror);
 }
   
}
*/

