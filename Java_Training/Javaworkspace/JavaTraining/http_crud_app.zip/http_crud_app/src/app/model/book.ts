export class Book
{
 bookid:number;
 bookname:string;
 bookauthor:string;

constructor(bookid:number,bookname:string,bookauthor:string)
{
    this.bookid = bookid;
    this.bookname = bookname;
    this.bookauthor = bookauthor;
}

getBookid():number
{
    return this.bookid;
}
getBookname():string
{
    return this.bookname
}
getBookauthor(): string
{
    return this.bookauthor;
}

getBook():string
{
    return 'bookid:' + this.bookid + ', bookname:' + this.bookname + ', bookauthor:' + this.bookauthor;
}
}