import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { BookdaoService } from '../bookdao.service';
import { Book } from '../model/book';

@Component({
  selector: 'app-bookform',
  templateUrl: './bookform.component.html',
  styleUrls: ['./bookform.component.css']
})
export class BookformComponent implements OnInit {
    

  bookdao:BookdaoService;
  book:Book;
  constructor(
    bookdao:BookdaoService,
    private router: Router) { 
    
    this.bookdao = bookdao;
    this.book=new Book(1,'','');
  }

  ngOnInit(): void {
    console.log('bookform component initialized');


  }

  submitform(form:any)
  {
    console.log('submit form called'+this.book);
    this.bookdao.addBook(this.book);
    // .subscribe(res => {
    //   console.log('Book created!')
    //   this.router.navigateByUrl('/home')
    // })
  }

    addBook(v1:string,v2:string,v3:string)
  {
    var b = new Book(+v1,v2,v3);

    this.bookdao.addBook(b);
    this.book = new Book(+b.bookid+1,'','');




  }

  //   this.bookdao.addBook(this.book).subscribe(
  //     {complete:()=>{console.log('addbook post completed..')},
  //     error:(error) => {console.log(error)},
  //     next: (response) => {console.log('book added successfully')
  //   }
  //   }
  //   )
  // }


  // addBook(v1:string,v2:string,v3:string)
  // {
  //   var b = new Book(+v1,v2,v3);

  //   this.bookdao.addBook(b);
  //   this.book = new Book(+b.bookid+1,'','');
  // }

}


  // addBook(arg0: any,arg1: any,arg2: any) {
// throw new Error('Method not implemented.');
// }
//   book!: FormGroup;

//   ngOnInit() {

//       this.book = new FormGroup({
//       bookid: new FormControl(''),
//       bookname: new FormControl(''),
//       bookauthor: new FormControl(''),
     
//     })

//     console.log(this.book);
//     console.log(this.book.value)
//     console.log(this.book.controls);
   
//   }

//   constructor(
//     public fb: FormBuilder,
//     private router: Router,
//     public crudService: BookdaoService
//   ){ }
//   submitForm() {
//     console.log('submit form called'+this.book.value);
//     this.crudService.addBook(this.book.value).subscribe(res => {
//       console.log('Book created!')
//       this.router.navigateByUrl('/home')

//   });

//  }
  
  


