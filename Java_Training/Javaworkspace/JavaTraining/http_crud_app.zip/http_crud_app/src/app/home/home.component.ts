import { Component, OnInit } from '@angular/core';
import { BookdaoService } from '../bookdao.service';
import { Book } from '../model/book';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  bookarr: Book[]
  bookdao:BookdaoService
  constructor(bookdao : BookdaoService) { 
    this.bookarr = [];
    this.bookdao = bookdao;
  }

  ngOnInit(): void {
  }

  getAllBooks(){
    this.bookdao.getAllBooks().subscribe(
      (data.Book[]) => {
        console.log(data);
        this.bookarr = data;
      }
    )
  }

}
