import { Component, OnInit } from '@angular/core';
import { BookdaoService } from '../bookdao.service';
import { Book } from '../model/book';

@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BooklistComponent implements OnInit {
  books: Book[] = [];

  constructor(public bookdao: BookdaoService) {
    this.bookdao = bookdao;
    this.books = [];
   }

  ngOnInit(): void {
    this.bookdao.getAll().subscribe((data: Book[])=>{
      console.log(data);
      this.books= data;
    })  
  }
  getallbooks()
  {
    this.bookdao.getAll().subscribe((data: Book[])=>{
      console.log(data);
      this.books= data;
    })  
  }


  deleteBook(bookid:number)
  {
    this.bookdao.delete(bookid).subscribe(()=>{
      console.log('book with bookid:'+bookid+' is deleted');
    });

     this.getallbooks();
   
  }

}