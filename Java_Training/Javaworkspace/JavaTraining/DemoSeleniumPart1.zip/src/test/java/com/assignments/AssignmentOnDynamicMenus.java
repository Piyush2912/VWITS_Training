package com.assignments;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.util.WebBrowser;

public class AssignmentOnDynamicMenus {
@Test
public void selectMenu() {
	WebDriver driver = WebBrowser.openBrowser("https://www.americangolf.co.uk/golf-clubs");
	Actions builder = new Actions(driver);
	//WebElement menu = driver.findElement(By.linkText("SwitchTo"));
	
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("button[data-tid='banner-accept']")));
	
	driver.findElement(By.cssSelector("button[data-tid='banner-accept']"));
	wait = new WebDriverWait(driver,Duration.ofSeconds(30));
	wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector(".a-level-1")));
	
	List<WebElement> menus = driver.findElements(By.cssSelector(".a-level-1"));
	for(WebElement menu : menus)
	{
		if (menu.getText().trim().equals("Golf Clubs"))
		{
			builder.moveToElement(menu).perform();
			break;
		}
	}
	wait = new WebDriverWait(driver,Duration.ofSeconds(30));
	wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("span.name")));
	
	List<WebElement> submenus = driver.findElements(By.xpath("span.name"));
	for(WebElement submenu : submenus)
	{
		System.out.println(submenu.getText());
		if(submenu.getText().trim().equals("Drivers"))
		{
			System.out.println("in if");
			submenu.click();
			break;
		}
	}
}
}
