package com.basic;

import static org.testng.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.util.WebBrowser;

public class WorkingOnTables1 {
	@Test
	public void verifyRowData() {
		int rowno = 3;
		String data = "Meta;Francisco Chang;Mexico";
		List<String> expdata = Arrays.asList(data.split(";"));
		List<String> actdata = new ArrayList<>();
		WebDriver driver = WebBrowser.openBrowser("https://www.techlistic.com/p/demo-selenium-practice.html");
		// All table cells //table[@id='customers']/tbody/tr/td
		//row data - //table[@id='customers']/tbody/tr[3]/td
		List<WebElement> rowdata = driver.findElements(By.xpath("//table[@id='customers']/tbody/tr[" + rowno + "]/td"));
		for(WebElement cell : rowdata) {
			actdata.add(cell.getText());
		}
		assertEquals(actdata,expdata);
	}
	
	@Test
	public void verifyCelldata() {
		int rowno = 3;
		int colno = 3;
		String expdata = "Mexico";
		
		WebDriver driver = WebBrowser.openBrowser("https://www.techlistic.com/p/demo-selenium-practice.html");
		//Cell data - //table[@id='customers']/tbody/tr[3]/td[3]
		WebElement cell = driver.findElement(By.xpath("//table[@id='customers']/tbody/tr[" + rowno + "]/td[" + colno + "]" ));
		String actdata = cell.getText();
		assertEquals(actdata,expdata);
	}
}
