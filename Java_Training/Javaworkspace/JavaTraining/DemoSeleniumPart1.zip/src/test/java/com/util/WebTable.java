package com.util;

import static org.testng.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class WebTable {
	
	public static List<String> getRowData(WebDriver driver,By locator,int rownum) {
		
		List<String> data = new ArrayList<>();
		WebElement table = driver.findElement(locator);
		List<WebElement> rows = table.findElements(By.tagName("tr"));
		
		WebElement row = rows.get(rownum - 1);
		
		List<WebElement> cells = row.findElements(By.tagName("td"));
		for(WebElement cell : cells) {
			data.add(cell.getText());
		}
		return data;
			
	}
	
	public static String getCellData(WebDriver driver,By locator,int rownum,int colno) {
		
		WebElement table = driver.findElement(locator);
		List<WebElement> rows = table.findElements(By.tagName("tr"));
		WebElement row = rows.get(rownum - 1);
		
		List<WebElement> cells = row.findElements(By.tagName("td"));
		WebElement cell = cells.get(colno - 1);
		
		return cell.getText();
		
	}
	
	@Test
	public void verifyTableData() {
		int rowno = 2;
		int colno = 2;
		String expdata = "Maria Anders";
		WebDriver driver = WebBrowser.openBrowser("https://www.techlistic.com/p/demo-selenium-practice.html");
		
		String actdata = WebTable.getCellData(driver, By.id("customers"), rowno, colno);
		assertEquals(actdata, expdata);
		
		String exprowdata = "Google;Maria Anders;Germany";
		List<String> exprdata = Arrays.asList(exprowdata.split(";"));
		List<String> actrdata = WebTable.getRowData(driver, By.id("customers"), rowno);
		
		assertEquals(actrdata, exprdata);
		driver.close();
	}
	
	
}
