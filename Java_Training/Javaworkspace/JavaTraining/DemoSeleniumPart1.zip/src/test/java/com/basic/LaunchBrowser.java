package com.basic;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;
public class LaunchBrowser {

		@Test
		public void openChrome() {
			System.setProperty("webdriver.chrome.driver", "src/test/resources/drivers/chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			driver.get("https://www.google.com");
			
//			Options op = driver.manage();
//			Window win = op.window();
//			win.maximize();
			
			driver.manage().window().maximize();
			
			String title = driver.getTitle();
			System.out.println("Title of page : " + title);
			
			System.out.println("Current url : " + driver.getCurrentUrl());
			driver.close();
		}
		
		@Test
		public void openFireFox() {
			System.setProperty("webdriver.gecko.driver", "src/test/resources/drivers/geckodriver.exe");
		}
}
