package com.assignments;

import static org.testng.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import com.util.WebBrowser;

public class AssignmentOnAutomation {
	@Test
	public void automateHtmlForm() {
		WebDriver driver = WebBrowser.openBrowser("https://demo.automationtesting.in/Register.html");
		
		// Automation on Text
		driver.findElement(By.xpath("//input[@ng-model='FirstName']")).sendKeys("Sad");
		driver.findElement(By.xpath("//input[@ng-model='LastName']")).sendKeys("Tom");
		driver.findElement(By.xpath("//textarea[@ng-model='Adress']")).sendKeys("Sad Town Road To Home");
		driver.findElement(By.xpath("//input[@ng-model='EmailAdress']")).sendKeys("sad@gmail.com");
		driver.findElement(By.xpath("//input[@ng-model='Phone']")).sendKeys("9998877766");
		driver.findElement(By.xpath("//input[@id='firstpassword']")).sendKeys("Help@Me");
		driver.findElement(By.xpath("//input[@id='secondpassword']")).sendKeys("Help@Me");
		
		
		// Validating for Radio Buttons
		List<WebElement> radios = driver.findElements(By.name("radiooptions"));
		for(WebElement rb:radios) {
			// selecting Female Radio button
			if(rb.getAttribute("value").equals("FeMale")) { 
				rb.click();
				break;
			}
		}
		
		for(WebElement rb:radios) {
			// selecting Male Radio button
			if(rb.getAttribute("value").equals("Male")) { 
				rb.click();
				break;
			}
		}
		
		
		// Validating for Check boxes
		List<WebElement> checkboxes = driver.findElements(By.cssSelector("input[type=checkbox]"));
		for(WebElement ch : checkboxes) {
			// selecting Movies check box
			if(ch.getAttribute("value").equals("Movies")) {
				if(!ch.isSelected()) {
					ch.click();
					break;
				}
			}
		}
		
		for(WebElement ch : checkboxes) {
			// selecting Cricket check box
			if(ch.getAttribute("value").equals("Cricket")) {
				if(!ch.isSelected()) {
					ch.click();
					break;
				}
			}
		}
		
		for(WebElement ch : checkboxes) {
			// selecting Hockey check box
			if(ch.getAttribute("value").equals("Hockey")) {
				if(!ch.isSelected()) {
					ch.click();
					break;
				}
			}
		}
		
		
		// Validating for Drop Downs
		
		boolean flag = false;
		
		// validating for Skills Drop Down and selecting option Java
		Select skills = new Select(driver.findElement(By.id("Skills")));
		
		List<WebElement> options = skills.getOptions();
		for(WebElement op : options) {
			if(op.getText().equals("Java")) {
			skills.selectByVisibleText("Java");
			flag = true;
			break;
			}
		}
		if(!flag) {
			System.out.println("Incorrect skill option sent");
		}
		
		// Validating for Country Drop Down and selecting option India
				flag = false;
				Select countrySelector = new Select(driver.findElement(By.id("country")));
				
				List<WebElement> countryOptions = countrySelector.getOptions();
				for(WebElement cs : countryOptions) {
					if(cs.getText().equals("India")) {
						countrySelector.selectByVisibleText("India");
					flag = true;
					break;
					}
				}
				if(!flag) {
					System.out.println("Incorrect Country option sent");
				}
		
		
		// Validating for Year Drop Down and selecting option 2000
		flag = false;
		Select yearSelection = new Select(driver.findElement(By.id("yearbox")));
		
		List<WebElement> yearOptions = yearSelection.getOptions();
		for(WebElement yearOption : yearOptions) {
			if(yearOption.getText().equals("2000")) {
				yearSelection.selectByVisibleText("2000");
			flag = true;
			break;
			}
		}
		if(!flag) {
			System.out.println("Incorrect year option sent");
		}
		
		// Validating for Day Drop Down and selecting option 25
		flag = false;
		Select daySelection = new Select(driver.findElement(By.id("daybox")));
		
		List<WebElement> days = daySelection.getOptions();
		for(WebElement day : days) {
			if(day.getText().equals("25")) {
				daySelection.selectByVisibleText("25");
				flag = true;
				break;
				}
			}
		if(!flag) {
			System.out.println("Incorrect day option sent");
			}
		
		
		// Validating for Month Drop Down and selecting option December
		flag = false;
		Select monthSelector = new Select(driver.findElement(By.xpath("//div[@class='form-group'][11]/div[2]/select")));
//		Select monthSelector = new Select(driver.findElement(By.xpath("//select[@ng-model='monthbox']")));

		
		List<WebElement> months = monthSelector.getOptions();
		for(WebElement mm : months) {
			if(mm.getText().equals("December")) {
				monthSelector.selectByVisibleText("December");
				flag = true;
				break;
				}
			}
		if(!flag) {
			System.out.println("Incorrect month option sent");
			}
		
		// Automation on multiple option selection
//		driver.findElement(By.xpath("//a[@class='ui-corner-all']"));
//		List<WebElement> multi =driver.findElements(By.xpath("//a[@class='ui-corner-all']"));
		driver.findElement(By.cssSelector("multi-select")).click();
		driver.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[7]/div/multi-select/div[2]/ul/li[8]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[7]/div/multi-select/div[2]/ul/li[10]/a")).click();
		
		
		driver.findElement(By.id("submitbtn")).click();
		
	}	
}
