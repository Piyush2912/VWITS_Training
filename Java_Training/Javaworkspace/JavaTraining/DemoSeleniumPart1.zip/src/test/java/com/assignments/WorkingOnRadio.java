package com.assignments;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.util.WebBrowser;

public class WorkingOnRadio {
	@Test
	public void selectTableRadio() {
		WebDriver driver = WebBrowser.openBrowser("https://echoecho.com/htmlforms10.htm");
		List<WebElement> radios = driver.findElements(By.name("radio1"));
		
		for(WebElement rb:radios) {
				rb.click();
				break;
		}
	}
}
