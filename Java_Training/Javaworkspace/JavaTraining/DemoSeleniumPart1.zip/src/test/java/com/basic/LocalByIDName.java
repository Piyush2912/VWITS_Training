package com.basic;

import com.util.WebBrowser;
import org.testng.annotations.*;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.*;
public class LocalByIDName {
	@Test
	public void invalidLogin() {
		
		String experror = "Invalid Username/Password";
		WebDriver driver = WebBrowser.openBrowser("https://echotrak.com/Login.aspx?ReturnUrl=%2fLoginEmp.aspx");
		WebElement username = driver.findElement(By.id("txtCustomerID"));
		username.sendKeys("admin");
		driver.findElement(By.id("txtPassword")).sendKeys("admin@12");
		driver.findElement(By.name("Butsub")).click();
		
		WebElement lblerror = driver.findElement(By.id("lblMsg"));
		String acterror = lblerror.getText();
		
		assertEquals(acterror,experror);
	}

}
