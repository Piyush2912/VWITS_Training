package util;

public class Payload {
	
	public static String createBooking(String firstname,String lastname, String checkin, String checkout)
	{
		return "{\r\n"
				+ "    \"firstname\": \"Sally\",\r\n"
				+ "    \"lastname\": \"Brown\",\r\n"
				+ "    \"totalprice\": 111,\r\n"
				+ "    \"depositpaid\": true,\r\n"
				+ "    \"bookingdates\": {\r\n"
				+ "        \"checkin\": \"2013-02-23\",\r\n"
				+ "        \"checkout\": \"2014-10-23\"\r\n"
				+ "    },\r\n"
				+ "    \"additionalneeds\": \"Breakfast\"\r\n"
				+ "}";
	}
}
