package basic;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class EmployeeAPI {
	RequestSpecification reqspec;
	Response response;
	@Test
	public void createEmployee() {
		RestAssured.baseURI = "https://reqres.in";
		 
		reqspec = given().log().all().header("content-type","application/json")
				.body("{\r\n"
						+ "    \"name\":\"morpheus\"\r\n"
						+ "    \"job\":\"zion resident\"\r\n"
						+ "}");
		response = reqspec.when().post("/api/users");
		response.then().log().all().statusCode(201)
		.body("name", equalTo("morpheus"))
		.body("job", equalTo("leader"));
	}
	
	@Test
	public void getEmployees() {
		RestAssured.baseURI="https://reqres.in";
		reqspec = given().log().all().header("content-type","application/json")
				.queryParam("page",2);
		response = reqspec.when().get("/api/users");
		
		response.then().log().all().assertThat().statusCode(200)
		.body("data.id", hasItems(7,8,9,10,11,12))
		.body("data.first_name", hasItems("Michael","Lindsay","Tobias","Byron","George","Rachel"));
		
		
	}
	
	
	@Test
	public void updateEmployee() {
		RestAssured.baseURI="https://reqres.in";
		reqspec = given().log().all().header("content-type","application/json")
				.pathParam("id",2);
		response = reqspec.when().get("/api/users/{id}");
		response.then().log().all().assertThat().statusCode(200);
	
	}
	
	@Test
	public void deleteEmployee()
	{
		RestAssured.baseURI = "https://reqres.in";
		reqspec = given().log().all().header("content-all","application/json")
				.pathParam("id",2);
		
		response = reqspec.when().delete("api/users/{id}");
		response.then().log().all().assertThat().statusCode(204);
		
	}
}
