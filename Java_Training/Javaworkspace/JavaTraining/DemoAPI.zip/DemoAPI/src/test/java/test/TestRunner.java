package test;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
	//	dryRun = true,
		features = "src/test/resources/Features/BookerAPI.feature",
		glue = "stepdifinitions",
		plugin = {"pretty","html:target/html-report.html"},
		monochrome = true
		)

public class TestRunner {

}
