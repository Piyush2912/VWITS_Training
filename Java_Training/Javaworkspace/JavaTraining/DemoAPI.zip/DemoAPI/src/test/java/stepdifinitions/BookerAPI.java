package stepdifinitions;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import java.util.Map;

import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import util.Payload;
import io.cucumber.datatable.DataTable;

public class BookerAPI {
	static RequestSpecification reqspec;
	static ResponseSpecification resspec;
	static Response response;
	@Before
	public void getSpecs()
	{
		reqspec = new RequestSpecBuilder()
				.addHeader("content-type","application/json")
				.setBaseUri("https://restful-booker.herokuapp.com").build();
		
		resspec = new ResponseSpecBuilder()
				.expectContentType(ContentType.JSON)
				.expectStatusCode(200).build();
	}
	@Given("The request specification for Create Booking API")
	public void the_request_specification_for_create_booking_api(DataTable dataTable) {
		Map<String, String> data = dataTable.asMap();
		reqspec = given().spec(reqspec).
				body(Payload.createBooking
				(data.get("firstname"),data.get("lastname"),data.get("checkin"),data.get("checkout")));
	}
	@When("I invoke create booking using http POST request")
	public void i_invoke_create_booking_using_http_post_request() {
		response = reqspec.when().post("/booking");
	}
	@Then("the status code is {int}")
	public void the_status_code_is(int expstatuscode) {
		response.then().log().all().statusCode(expstatuscode);
	}
	@Then("Response has {string} equal to {string}")
	public void response_has_equal_to(String path, String expvalue) {
		response.then().body(path, equalTo(expvalue));
	}



}
