package stepdefinitions;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import util.WebBrowser;
import io.cucumber.datatable.DataTable;
public class DemoRegistration {
	WebDriver driver;
	@Given("User is at Demo Registration page")
	public void user_is_at_demo_registration_page() {
		driver = WebBrowser.openBrowser("https://demo.automationtesting.in/Register.html");
	}
	@When("User enter registration data as")
	public void user_enter_registration_data_as(DataTable dataTable) {
		Map<String,String> data = dataTable.asMap();
		driver.findElement(By.xpath("//input[@ng-model='EmailAdress']")).sendKeys(data.get("email"));
		driver.findElement(By.xpath("//input[@ng-model='Phone']")).sendKeys(data.get("phoneno"));
		if(data.get("gender").equals("Male")) {
			driver.findElement(By.xpath("//input[@value='Male']")).click();
		}else {
			driver.findElement(By.xpath("//input[@value='FeMale']")).click();
		}
		Select skills = new Select(driver.findElement(By.id("Skills")));
		skills.selectByVisibleText(data.get("skills"));
		Select country = new Select(driver.findElement(By.className("select2-hidden-accessible")));
		country.selectByVisibleText(data.get("country"));
	}
	@When("User click on Submit")
	public void user_click_on_submit() {
		driver.findElement(By.id("submitbtn")).click();
	   }
	@Then("User new account is created")
	public void user_new_account_is_created() {
		System.out.println("Demo Registration Success");
	}



}
