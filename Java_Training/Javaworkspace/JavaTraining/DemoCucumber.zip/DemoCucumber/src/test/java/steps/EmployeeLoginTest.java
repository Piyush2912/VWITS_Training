package steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class EmployeeLoginTest {
	
	@Given("I am on the Employee Login page")
	public void i_am_on_the_employee_login_page() {
		SetUp.login().navigateToEmpLogin();
	}
	@When("Employee logs in with {string} and {string}")
	public void employee_logs_in_with_and(String username, String password) {
		SetUp.elogin().empLogin(username,password);
	}
	@Then("Employee can access the account")
	public void employee_can_access_the_account() {
		System.out.println("Employee Login Success");

	}
	





}
