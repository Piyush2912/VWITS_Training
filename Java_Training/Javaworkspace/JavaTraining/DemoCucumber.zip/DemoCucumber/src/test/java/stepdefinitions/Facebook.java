package stepdefinitions;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import util.WebBrowser;
import io.cucumber.datatable.DataTable;

public class Facebook {
	WebDriver driver;
	@When("On Facebook login page")
	public void on_facebook_login_page() {
		driver = WebBrowser.openBrowser("https://www.facebook.com/login");
		driver.findElement(By.id("u_0_c_Ep")).click();
	}
	@Then("Registred users log-in successfully")
	public void registred_users_log_in_successfully(DataTable dataTable) {
		List<List<String>> ldata = dataTable.asLists();
		for(List<String> data: ldata) {
			driver.findElement(By.id("email")).sendKeys(data.get(0));
			driver.findElement(By.id("pass")).sendKeys(data.get(1));
			driver.findElement(By.name("login")).click();
			driver.navigate().refresh();
		}
		
	}
	
	@Then("The Registred users log-in successfully")
		public void The_Registred_users_log_in_successfully(DataTable dataTable){
			List<Map<String,String>> mdata = dataTable.asMaps();
			for(Map<String, String> data: mdata) {
				driver.findElement(By.id("email")).sendKeys(data.get("username"));
				driver.findElement(By.id("pass")).sendKeys(data.get("password"));
				driver.findElement(By.name("login")).click();
				driver.navigate().refresh();
					
			}
		}
	

}
