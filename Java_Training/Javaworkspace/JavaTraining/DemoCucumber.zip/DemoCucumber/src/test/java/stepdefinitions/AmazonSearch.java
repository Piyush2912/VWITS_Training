package stepdefinitions;

import static org.testng.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import util.WebBrowser;

public class AmazonSearch {
	WebDriver driver;
	
	@Given("I am on the Amazon Home page")
	public void i_am_on_the_amazon_home_page() {
		driver = WebBrowser.openBrowser("https://www.amazon.de/");
	}
	@When("I enter {string} on search box")
	public void i_enter_on_search_box(String product) {
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys(product);
	}
	@And("I click on search button")
	public void i_click_on_search_button() {
		driver.findElement(By.id("nav-search-submit-button")).click();
	}
	@Then("I can see {string} products")
	public void i_can_see_products(String string) {
		System.out.println("Result search successfull");
	}
	@When("I search for {string}")
	public void i_search_for(String product) {
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys(product);
	}
	@Then("Results for {string} are displayed")
	public void results_for_are_displayed(String product) {
		String title = driver.getTitle();
		assertTrue(title.contains(product));
	}
	
	
	@When("I filter using price {string}")
	public void i_filter_using_price(String string) {
		
		
	}
	
	@Then("The results are filtered")
	public void the_results_are_filtered() {
		System.out.println("Done");
	}
	
	@When("I sort by {string}")
	public void i_sort_by(String string) {
	
	}
	
	@Then("The results are sorted")
	public void the_results_are_sorted() {
	}









}
