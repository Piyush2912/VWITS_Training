package pageextensions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EmployeeLogin {
	
	//Page properties
	@FindBy(id="ctl00_contentPlaceHolder_txtCustomerID")
	private WebElement txtusername;
	@FindBy(id="ctl00_contentPlaceHolder_txtPassword")
	private WebElement txtpassword;
	@FindBy(id="ctl00_contentPlaceHolder_Butsub")
	private WebElement btnlogin;
	
	//Page behaviours
	public EmployeeLogin(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	public void empLogin(String username,String password)
	{
		txtusername.sendKeys(username);
		txtpassword.sendKeys(password);
		btnlogin.click();
	}
}
