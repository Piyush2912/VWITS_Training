package pageextensions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Login {
	
	// Page Properties
	
	//WebDriver driver
	WebDriver driver;
	
	// private By txtusername = By.id("");
	@FindBy(id="txtCustomerID")
	private WebElement txtusername;
	@FindBy(id="txtPassword")
	private WebElement txtpassword;
	@FindBy(id="Butsub")
	private WebElement btnsignin;
	@FindBy(linkText = "Echo Employee Login")
	private WebElement lnkemplogin;
	@FindBy(css = "h4.section-label")
	private WebElement lblheading;
	@FindBy(id="lblMsg")
	private WebElement lblerror;

	public Login(WebDriver driver)
	{
		//this.driver = driver;
		//txxtusername = driver.findElement(By.id("");
		PageFactory.initElements(driver, this);
		
	}
	// Page behaviour
	public void login(String username, String password)
	{
		//driver.findElement(txtusername).sendKeys(username);
		txtusername.sendKeys(username);
		txtpassword.sendKeys(password);
		btnsignin.click();
	}
	public void navigateToEmpLogin()
	{
		lnkemplogin.click();
	}
	public String getPageHeading()
	{
		return lblheading.getText();
	}
	public String getError() {
		return lblerror.getText();
	}
	public void clearData() {
		txtusername.clear();
		txtpassword.clear();
	}
	
}
